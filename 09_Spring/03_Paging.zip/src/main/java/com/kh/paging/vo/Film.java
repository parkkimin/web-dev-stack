package com.kh.paging.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data@NoArgsConstructor@AllArgsConstructor
public class Film {
	
	private int filmID;
	private String filmTitle;
	private String filmDesc;

}
